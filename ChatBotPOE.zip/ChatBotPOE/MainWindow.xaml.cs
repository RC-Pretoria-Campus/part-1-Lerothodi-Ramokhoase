﻿using System;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Threading;
using System.Speech.Synthesis;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows.Data;
using System.Linq;
using System.Collections.Generic;

namespace ChatBotPOE
{
    public class NullToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value == null ? Visibility.Collapsed : Visibility.Visible;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public partial class MainWindow : Window
    {
        private string userName = "";
        private readonly SpeechSynthesizer synth = new SpeechSynthesizer();
        private bool speechEnabled = true;
        private readonly DispatcherTimer typingTimer;
        private string currentTypingText = "";
        private int typingPosition = 0;
        private bool isTyping = false;
        private Paragraph currentTypingParagraph;
        private readonly Random random = new Random();

        // Task management
        public class CyberTask
        {
            public string Title { get; set; }
            public string Description { get; set; }
            public DateTime? ReminderDate { get; set; }
            public bool IsCompleted { get; set; }
        }
        private readonly ObservableCollection<CyberTask> tasks = new ObservableCollection<CyberTask>();

        // Quiz management
        public class QuizQuestion
        {
            public string Question { get; set; }
            public List<string> Options { get; set; }
            public int CorrectAnswerIndex { get; set; }
            public string Explanation { get; set; }
        }
        private readonly List<QuizQuestion> quizQuestions = new List<QuizQuestion>();
        private int quizScore = 0;
        private int currentQuestionIndex = -1;
        private bool quizInProgress = false;

        // Activity log
        public class ActivityLogEntry
        {
            public DateTime Timestamp { get; set; }
            public string Action { get; set; }
            public string Details { get; set; }
        }
        private readonly List<ActivityLogEntry> activityLog = new List<ActivityLogEntry>();
        private const int MaxLogEntries = 10;

        // Memory features
        private string userInterest = "";
        private string lastTopic = "";
        private bool wantsMoreInfo = false;
        private readonly HashSet<string> discussedTopics = new HashSet<string>();

        // Sentiment dictionaries
        private readonly Dictionary<string, string> positiveWords = new Dictionary<string, string>
        {
            {"happy", "positive"}, {"good", "positive"}, {"great", "positive"},
            {"excellent", "positive"}, {"awesome", "positive"}, {"thanks", "positive"}
        };

        private readonly Dictionary<string, string> negativeWords = new Dictionary<string, string>
        {
            {"worried", "concerned"}, {"scared", "fearful"}, {"frustrated", "frustrated"},
            {"angry", "angry"}, {"confused", "confused"}, {"overwhelmed", "overwhelmed"},
            {"unsure", "uncertain"}, {"nervous", "anxious"}, {"afraid", "fearful"}
        };

        private readonly Dictionary<string, string> neutralWords = new Dictionary<string, string>
        {
            {"curious", "curious"}, {"interested", "interested"}, {"wondering", "pondering"},
            {"thinking", "contemplative"}, {"question", "inquisitive"}
        };

        public MainWindow()
        {
            InitializeComponent();
            ToggleSpeechButton.Content = speechEnabled ? "🔊 Speech On" : "🔇 Speech Off";
            InitializeQuizQuestions();
            TasksListBox.ItemsSource = tasks;

            typingTimer = new DispatcherTimer();
            typingTimer.Interval = TimeSpan.FromMilliseconds(20);
            typingTimer.Tick += TypingTimer_Tick;

            InitializeChatbot();
        }
        private void InitializeQuizQuestions()
        {
            quizQuestions.Add(new QuizQuestion
            {
                Question = "What should you do if you receive an email asking for your password?",
                Options = new List<string> { "Reply with your password", "Delete the email", "Report the email as phishing" },
                CorrectAnswerIndex = 2,
                Explanation = "Correct! Reporting phishing emails helps prevent scams."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "Which of these is the strongest password?",
                Options = new List<string> { "password123", "P@ssw0rd!", "BlueCoffeeMug42!" },
                CorrectAnswerIndex = 2,
                Explanation = "Correct! Passphrases with mixed characters are strongest."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "What is two-factor authentication?",
                Options = new List<string> { "Using two passwords", "A method using password plus another verification", "A type of firewall" },
                CorrectAnswerIndex = 1,
                Explanation = "Correct! 2FA requires something you know (password) and something you have (phone, token)."
            });

            // Add 7 more questions to reach 10 total
            quizQuestions.Add(new QuizQuestion
            {
                Question = "What should you do before connecting to public Wi-Fi?",
                Options = new List<string> { "Use it normally", "Disable file sharing", "Share your personal files" },
                CorrectAnswerIndex = 1,
                Explanation = "Correct! Always disable file sharing on public networks."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "How often should you update your software?",
                Options = new List<string> { "Never", "Only when it stops working", "As soon as updates are available" },
                CorrectAnswerIndex = 2,
                Explanation = "Correct! Regular updates patch security vulnerabilities."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "What is a common sign of a phishing website?",
                Options = new List<string> { "HTTPS in the URL", "Misspelled domain name", "Professional design" },
                CorrectAnswerIndex = 1,
                Explanation = "Correct! Phishers often use domains like 'paypai' instead of 'paypal'."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "What should you do with suspicious email attachments?",
                Options = new List<string> { "Open them to check", "Forward to friends", "Delete without opening" },
                CorrectAnswerIndex = 2,
                Explanation = "Correct! Never open suspicious attachments."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "What is social engineering?",
                Options = new List<string> { "A type of software", "Manipulating people to reveal information", "A programming language" },
                CorrectAnswerIndex = 1,
                Explanation = "Correct! It's psychological manipulation to gain access to information."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "How can you verify a website is secure?",
                Options = new List<string> { "Check for HTTPS", "Look for colorful design", "See if it has many ads" },
                CorrectAnswerIndex = 0,
                Explanation = "Correct! HTTPS indicates encrypted communication."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "What is ransomware?",
                Options = new List<string> { "A type of insurance", "Malware that encrypts files for ransom", "A password manager" },
                CorrectAnswerIndex = 1,
                Explanation = "Correct! Ransomware locks your files until you pay."
            });
        }

        private void InitializeChatbot()
        {
            ChatDisplay.Document.Blocks.Clear();
            QueueBotMessage("Hello. Welcome to the Cybersecurity Awareness Bot. Please enter your name.");

            synth.SetOutputToDefaultAudioDevice();
            SpeakMessage("Hello. Welcome to the Cybersecurity Awareness Bot. Please enter your name.");
        }

        private void TypingTimer_Tick(object sender, EventArgs e)
        {
            if (typingPosition >= currentTypingText.Length)
            {
                typingTimer.Stop();
                isTyping = false;

                if (currentTypingParagraph?.Inlines.LastInline is Run lastInline && lastInline.Text.EndsWith("|"))
                {
                    currentTypingParagraph.Inlines.Remove(lastInline);
                }
                return;
            }

            if (currentTypingParagraph?.Inlines.LastInline is Run currentRun && currentRun.Text.EndsWith("|"))
            {
                currentTypingParagraph.Inlines.Remove(currentRun);
            }

            currentTypingParagraph.Inlines.Add(new Run(currentTypingText[typingPosition].ToString()) { Foreground = Brushes.Blue });
            typingPosition++;

            currentTypingParagraph.Inlines.Add(new Run("|") { Foreground = Brushes.Blue });
            ChatDisplay.ScrollToEnd();
        }

        private void QueueBotMessage(string message)
        {
            if (isTyping)
            {
                EventHandler handler = null;
                handler = (s, e) =>
                {
                    if (!isTyping)
                    {
                        typingTimer.Tick -= handler;
                        StartTypingMessage(message);
                    }
                };
                typingTimer.Tick += handler;
            }
            else
            {
                StartTypingMessage(message);
            }
        }

        private void StartTypingMessage(string message)
        {
            currentTypingParagraph = new Paragraph(new Run("Bot: ") { FontWeight = FontWeights.Bold });
            ChatDisplay.Document.Blocks.Add(currentTypingParagraph);

            currentTypingText = message;
            typingPosition = 0;
            isTyping = true;
            typingTimer.Start();

            SpeakMessage(message);
        }

        private void SpeakMessage(string message)
        {
            if (!speechEnabled) return;

            try
            {
                synth.SpeakAsync(message);
            }
            catch (Exception ex)
            {
                Dispatcher.Invoke(() =>
                {
                    StatusText.Text = "Speech synthesis error: " + ex.Message;
                });
            }
        }

        private void AddUserMessage(string message)
        {
            var paragraph = new Paragraph(new Run($"{userName}: ") { FontWeight = FontWeights.Bold });
            paragraph.Inlines.Add(new Run(message));
            ChatDisplay.Document.Blocks.Add(paragraph);
            ChatDisplay.ScrollToEnd();
        }

        private void ProcessUserInput(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                QueueBotMessage("Please enter something.");
                return;
            }

            if (string.IsNullOrEmpty(userName))
            {
                userName = input;
                AddToActivityLog("User registration", $"User provided name: {userName}");
                QueueBotMessage($"Hello, {userName}! Welcome to the Cybersecurity Awareness Bot!");
                QueueBotMessage("I can help you with various cybersecurity topics including:");
                QueueBotMessage("- Password safety and creation");
                QueueBotMessage("- Recognizing and avoiding scams");
                QueueBotMessage("- Protecting your online privacy");
                QueueBotMessage("- Phishing prevention tips");
                QueueBotMessage("- Malware and ransomware protection");
                QueueBotMessage("I can also help you manage cybersecurity tasks, set reminders, and test your knowledge with a quiz!");
                QueueBotMessage("What would you like to do today?");
                return;
            }

            // Check for quiz answers if quiz is in progress
            if (quizInProgress)
            {
                ProcessQuizAnswer(input);
                return;
            }

            // Check for commands
            if (TryProcessCommand(input))
            {
                return;
            }

            // Check for follow-up requests
            if (wantsMoreInfo && !input.ToLower().Contains("no") && !input.ToLower().Contains("stop"))
            {
                wantsMoreInfo = false;
                string GetResponse = GetMoreInfoResponse(lastTopic);
                if (!string.IsNullOrEmpty(GetResponse))
                {
                    QueueBotMessage(GetResponse);
                    return;
                }
            }

            // Check if user is asking for more information
            if (input.ToLower().Contains("more") || input.ToLower().Contains("detail") ||
                input.ToLower().Contains("explain") || input.ToLower().Contains("elaborate"))
            {
                wantsMoreInfo = true;
                string GetResponse = GetMoreInfoResponse(lastTopic);
                if (!string.IsNullOrEmpty(GetResponse))
                {
                    QueueBotMessage(GetResponse);
                    return;
                }
            }

            string response = GetResponse(input);
            QueueBotMessage(response);
        }

        private bool TryProcessCommand(string input)
        {
            string lowerInput = input.ToLower();

            // Task commands
            if (lowerInput.Contains("add task") || lowerInput.Contains("create task"))
            {
                ProcessAddTaskCommand(input);
                return true;
            }

            if (lowerInput.Contains("set reminder") || lowerInput.Contains("remind me"))
            {
                ProcessSetReminderCommand(input);
                return true;
            }

            if (lowerInput.Contains("show tasks") || lowerInput.Contains("list tasks"))
            {
                ShowTaskList();
                return true;
            }

            // Quiz commands
            if (lowerInput.Contains("start quiz") || lowerInput.Contains("take quiz"))
            {
                StartQuiz();
                return true;
            }

            // Activity log commands
            if (lowerInput.Contains("show log") || lowerInput.Contains("activity log") ||
                lowerInput.Contains("what have you done"))
            {
                ShowActivityLog();
                return true;
            }

            return false;
        }

        private void ProcessAddTaskCommand(string input)
        {
            string taskTitle = ExtractTaskTitle(input);

            if (string.IsNullOrWhiteSpace(taskTitle))
            {
                QueueBotMessage("I couldn't determine what task you want to add. Please try again.");
                return;
            }

            var newTask = new CyberTask
            {
                Title = taskTitle,
                Description = $"Cybersecurity task: {taskTitle}",
                ReminderDate = null,
                IsCompleted = false
            };

            tasks.Add(newTask);
            AddToActivityLog("Task added", $"Task: {taskTitle}");
            QueueBotMessage($"Task added: {taskTitle}. Would you like to set a reminder for this task?");
        }

        private string ExtractTaskTitle(string input)
        {
            var match = Regex.Match(input, @"(?:task to|task|add|create)\s+(.+)", RegexOptions.IgnoreCase);
            return match.Success ? match.Groups[1].Value.Trim() : input;
        }

        private void ProcessSetReminderCommand(string input)
        {
            var match = Regex.Match(input, @"remind me to (.+) (tomorrow|in \d+ days?)", RegexOptions.IgnoreCase);
            if (match.Success)
            {
                string task = match.Groups[1].Value.Trim();
                string when = match.Groups[2].Value;

                DateTime reminderDate = when.Contains("tomorrow")
                    ? DateTime.Now.AddDays(1)
                    : DateTime.Now.AddDays(int.Parse(Regex.Match(when, @"\d+").Value));

                var newTask = new CyberTask
                {
                    Title = task,
                    Description = $"Reminder: {task}",
                    ReminderDate = reminderDate,
                    IsCompleted = false
                };

                tasks.Add(newTask);
                AddToActivityLog("Reminder set", $"Task: {task}, Reminder: {reminderDate}");
                QueueBotMessage($"Reminder set for {task} on {reminderDate.ToShortDateString()}.");
            }

            else
            {
                QueueBotMessage("I couldn't understand when you want to be reminded. Please try something like 'Remind me to update my password tomorrow'.");
            }
        }

        private void ShowTaskList()
        {
            if (tasks.Count == 0)
            {
                QueueBotMessage("You don't have any tasks yet. You can add one by saying 'Add task to enable two-factor authentication'.");
                return;
            }

            QueueBotMessage("Here are your current tasks:");
            foreach (var task in tasks)
            {
                string reminderText = task.ReminderDate.HasValue
                    ? $" (Reminder: {task.ReminderDate.Value.ToShortDateString()})"
                    : "";
                QueueBotMessage($"- {task.Title}{reminderText}");
            }
            AddToActivityLog("Tasks viewed", $"Viewed {tasks.Count} tasks");
        }

        private void StartQuiz()
        {
            quizInProgress = true;
            quizScore = 0;
            currentQuestionIndex = -1;
            AskNextQuizQuestion();
            AddToActivityLog("Quiz started", "User began cybersecurity quiz");
        }

        private void AskNextQuizQuestion()
        {
            currentQuestionIndex++;
            if (currentQuestionIndex < quizQuestions.Count)
            {
                var question = quizQuestions[currentQuestionIndex];
                string options = string.Join("\n", question.Options.Select((o, i) => $"{i + 1}. {o}"));
                QueueBotMessage($"Question {currentQuestionIndex + 1}: {question.Question}\n{options}");
            }
            else
            {
                EndQuiz();
            }
        }

        private void ProcessQuizAnswer(string input)
        {
            var currentQuestion = quizQuestions[currentQuestionIndex];
            int answer;

            if (int.TryParse(input, out answer) && answer >= 1 && answer <= currentQuestion.Options.Count)
            {
                if (answer - 1 == currentQuestion.CorrectAnswerIndex)
                {
                    quizScore++;
                    QueueBotMessage($"{currentQuestion.Explanation} Your answer was correct!");
                }
                else
                {
                    QueueBotMessage($"Sorry, that's incorrect. {currentQuestion.Explanation}");
                }
                AskNextQuizQuestion();
            }
            else
            {
                QueueBotMessage("Please enter the number of your answer (e.g., '1', '2', etc.).");
            }
        }

        private void EndQuiz()
        {
            quizInProgress = false;
            string feedback = quizScore >= quizQuestions.Count * 0.8
                ? "Excellent! You're a cybersecurity pro!"
                : quizScore >= quizQuestions.Count * 0.5
                    ? "Good effort! You might want to review some cybersecurity basics."
                    : "Keep learning! Cybersecurity is important for everyone.";

            QueueBotMessage($"Quiz complete! Your score: {quizScore}/{quizQuestions.Count}. {feedback}");
            AddToActivityLog("Quiz completed", $"Score: {quizScore}/{quizQuestions.Count}");
        }

        private void ShowActivityLog()
        {
            QueueBotMessage("Here's a summary of recent actions:");
            int count = Math.Min(activityLog.Count, MaxLogEntries);
            for (int i = 0; i < count; i++)
            {
                var entry = activityLog[activityLog.Count - 1 - i];
                QueueBotMessage($"{i + 1}. {entry.Action} - {entry.Details} ({entry.Timestamp.ToShortTimeString()})");
            }
            AddToActivityLog("Activity log viewed", "User viewed activity history");
        }

        private void AddToActivityLog(string action, string details)
        {
            activityLog.Add(new ActivityLogEntry
            {
                Timestamp = DateTime.Now,
                Action = action,
                Details = details
            });

            if (activityLog.Count > MaxLogEntries * 2)
            {
                activityLog.RemoveRange(0, activityLog.Count - MaxLogEntries);
            }
        }

        private string GetResponse(string query)
        {
            string lowerQuery = query.ToLower();
            string detectedSentiment = DetectSentiment(lowerQuery);

            // Handle sentiment-specific responses first
            string sentimentResponse = GetSentimentResponse(detectedSentiment, lowerQuery);
            if (!string.IsNullOrEmpty(sentimentResponse))
            {
                return sentimentResponse;
            }

            // Greetings and basic questions
            if (lowerQuery.Contains("what are you"))
                return "I am a Cybersecurity Awareness Bot designed to educate users about online safety and help manage cybersecurity tasks.";

            if (lowerQuery.Contains("what is your purpose") || lowerQuery.Contains("why do you exist"))
                return "My purpose is to provide information and raise awareness about cybersecurity topics to help you stay safe online, and to assist with cybersecurity-related tasks.";

            // Enhanced keyword recognition with conversation memory
            if (lowerQuery.Contains("password safety") || lowerQuery.Contains("passwords"))
            {
                lastTopic = "password";
                discussedTopics.Add("password safety");
                return GetPasswordSafetyResponse();
            }

            if (lowerQuery.Contains("password manager"))
            {
                lastTopic = "password";
                discussedTopics.Add("password managers");
                return GetPasswordManagerResponse();
            }

            if (lowerQuery.Contains("scam") || lowerQuery.Contains("scams"))
            {
                lastTopic = "scams";
                discussedTopics.Add("scams");
                return GetScamResponse();
            }

            if (lowerQuery.Contains("privacy") || lowerQuery.Contains("data protection"))
            {
                lastTopic = "privacy";
                userInterest = "privacy";
                discussedTopics.Add("privacy");
                return GetPersonalizedPrivacyResponse();
            }

            if (lowerQuery.Contains("phishing") || lowerQuery.Contains("phish"))
            {
                lastTopic = "phishing";
                discussedTopics.Add("phishing");
                return "Phishing is online fraud where attackers trick you into revealing sensitive information through fake emails or websites. Always verify senders and never click suspicious links. Would you like more details about phishing?";
            }

            // Other cybersecurity topics
            if (lowerQuery.Contains("what is cybersecurity") || lowerQuery.Contains("cybersecurity"))
            {
                lastTopic = "cybersecurity";
                discussedTopics.Add("cybersecurity basics");
                return "Cybersecurity protects computer systems, networks, and data from unauthorized access or damage. It ensures confidentiality, integrity, and availability of information.";
            }

            if (lowerQuery.Contains("malware") || lowerQuery.Contains("virus"))
            {
                lastTopic = "malware";
                discussedTopics.Add("malware");
                return "Malware is malicious software including viruses, worms, and spyware. Protect yourself with updated antivirus and by avoiding suspicious links/downloads.";
            }

            if (lowerQuery.Contains("ransomware"))
            {
                lastTopic = "ransomware";
                discussedTopics.Add("ransomware");
                return "Ransomware encrypts your files and demands payment. Protect yourself with regular backups, software updates, and by avoiding suspicious attachments.";
            }

            if (lowerQuery.Contains("thank you") || lowerQuery.Contains("thanks"))
                return GetRandomThankYouResponse();

            if (lowerQuery.Contains("exit") || lowerQuery.Contains("bye") || lowerQuery.Contains("goodbye"))
            {
                SpeakMessage($"Goodbye, {userName}! Stay safe online!");
                Close();
                return $"Goodbye, {userName}! Stay safe online!";
            }

            // Reference previous topics if user seems confused
            if (lowerQuery.Contains("what") || lowerQuery.Contains("confused") || lowerQuery.Contains("help"))
            {
                if (discussedTopics.Count > 0)
                {
                    return $"We recently discussed {string.Join(" and ", discussedTopics)}. Would you like me to go over any of these topics again or provide more details?";
                }
            }

            return "I'm not sure I understand. Could you ask about a specific cybersecurity topic? I can help with passwords, scams, privacy, phishing, and more. I can also help manage tasks or test your knowledge with a quiz!";
        }

        private string DetectSentiment(string input)
        {
            // Check for negative words first
            foreach (var word in negativeWords.Keys)
            {
                if (input.Contains(word))
                {
                    return negativeWords[word];
                }
            }

            // Check for positive words
            foreach (var word in positiveWords.Keys)
            {
                if (input.Contains(word))
                {
                    return positiveWords[word];
                }
            }

            // Check for neutral/curious words
            foreach (var word in neutralWords.Keys)
            {
                if (input.Contains(word))
                {
                    return neutralWords[word];
                }
            }

            return "neutral";
        }

        private string GetSentimentResponse(string sentiment, string query)
        {
            switch (sentiment)
            {
                case "concerned":
                case "fearful":
                case "frustrated":
                case "overwhelmed":
                    return GetSupportiveResponse(query);

                case "angry":
                    return "I understand this topic might be frustrating. Cybersecurity issues can be upsetting, but I'm here to help you navigate them safely.";

                case "confused":
                case "uncertain":
                    return "It's okay to feel unsure about cybersecurity topics. Let me explain this in a simpler way to help you understand better.";

                case "curious":
                case "interested":
                    return "I'm glad you're curious about cybersecurity! It's great that you're taking an interest in staying safe online.";

                case "positive":
                    if (query.Contains("thank") || query.Contains("thanks"))
                    {
                        return null; // Let the normal thank you response handle this
                    }
                    return "I'm glad you're feeling positive about learning cybersecurity! It's an important skill these days.";

                default:
                    return null;
            }
        }

        private string GetSupportiveResponse(string query)
        {
            if (query.Contains("scam") || query.Contains("fraud"))
            {
                return "It's completely understandable to feel that way. Scammers can be very convincing. " +
                       "Let me share some specific tips to help you recognize and avoid scams.";
            }
            else if (query.Contains("hack") || query.Contains("breach"))
            {
                return "Hearing about breaches can be worrying, but there are concrete steps you can take to protect yourself. " +
                       "Would you like me to go through them?";
            }
            else if (query.Contains("privacy") || query.Contains("data"))
            {
                return "Privacy concerns are very valid in today's digital world. " +
                       "I can help you understand how to better control your personal information online.";
            }
            else if (query.Contains("password") || query.Contains("account"))
            {
                return "Managing passwords can feel overwhelming, but with the right approach it becomes much easier. " +
                       "Would you like me to explain some simple password management strategies?";
            }
            else
            {
                return "I understand this topic might be concerning. Cybersecurity can feel overwhelming, but I'm here to help break it down into manageable steps.";
            }
        }

        private string GetMoreInfoResponse(string topic)
        {
            switch (topic)
            {
                case "password":
                    return "More about passwords: Did you know that 81% of hacking-related breaches use stolen or weak passwords? Consider using passphrases (like 'BlueCoffeeMug42!') which are easier to remember but harder to crack than traditional passwords.";

                case "scams":
                    return "Additional scam info: Scammers often create a sense of urgency to pressure you into acting quickly. Always take time to verify requests, especially those asking for money or personal information. When in doubt, contact the organization directly through official channels.";

                case "privacy":
                    return "Deeper privacy tips: Beyond basic settings, consider using privacy-focused browsers like Firefox or Brave, and search engines like DuckDuckGo. Regularly review which apps have access to your location, contacts, and other sensitive data on your mobile devices.";

                case "phishing":
                    return "Advanced phishing protection: Some phishing attempts are very sophisticated (called 'spear phishing'). Be extra careful with emails that appear to come from colleagues or services you use. Look for slight misspellings in domain names (like 'paypai.com' instead of 'paypal.com').";

                case "malware":
                    return "More malware details: Modern malware can be 'fileless', operating in memory without installing files. Keep your systems patched, use application whitelisting if possible, and be cautious with macros in documents from untrusted sources.";

                default:
                    return "I'd be happy to provide more information. Could you specify which aspect you'd like to know more about?";
            }
        }

        private string GetPasswordSafetyResponse()
        {
            return "For strong password safety:\n" +
                   "- Use a combination of uppercase and lowercase letters, numbers, and symbols\n" +
                   "- Make it at least 12 characters long\n" +
                   "- Avoid using personal information like birthdays or names\n" +
                   "- Never reuse passwords across different accounts\n" +
                   "- Consider using a reputable password manager";
        }

        private string GetPasswordManagerResponse()
        {
            return "Password managers are tools that store and manage all your passwords securely. Benefits include:\n" +
                   "- Generating strong, unique passwords for each account\n" +
                   "- Encrypted storage of all your passwords\n" +
                   "- Auto-filling login forms\n" +
                   "- Synchronizing across devices\n" +
                   "Popular options include LastPass, Bitwarden, and 1Password.";
        }

        private string GetScamResponse()
        {
            return "Common online scams to watch for:\n" +
                   "- Phishing emails pretending to be from trusted companies\n" +
                   "- Fake tech support calls claiming your computer has issues\n" +
                   "- Romance scams on dating sites\n" +
                   "- 'Too good to be true' investment opportunities\n" +
                   "Always verify unexpected requests for money or information.";
        }

        private string GetPersonalizedPrivacyResponse()
        {
            string baseResponse = "To protect your privacy online:\n" +
                   "- Review privacy settings on social media accounts\n" +
                   "- Be cautious about what personal information you share\n" +
                   "- Use two-factor authentication where available\n" +
                   "- Consider using a VPN on public Wi-Fi\n" +
                   "- Regularly check app permissions on your devices";

            if (!string.IsNullOrEmpty(userName))
            {
                baseResponse = $"{userName}, since you're interested in privacy: " + baseResponse;
            }

            if (userInterest == "privacy")
            {
                baseResponse += "\n\nAs someone who cares about privacy, you might also want to look into encrypted messaging apps like Signal for sensitive communications.";
            }

            return baseResponse;
        }

        private string GetRandomThankYouResponse()
        {
            var responses = new[]
            {
                "You're welcome! Stay safe online!",
                "Happy to help! Feel free to ask more cybersecurity questions.",
                "No problem! Cybersecurity awareness is important for everyone.",
                "Glad I could assist. Remember to practice good cyber hygiene!",
                "Anytime! Let me know if you have other security questions."
            };

            return responses[random.Next(responses.Length)];
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            string input = UserInput.Text.Trim();
            if (!string.IsNullOrEmpty(input))
            {
                AddUserMessage(input);
                UserInput.Clear();
                ProcessUserInput(input);
            }
        }

        private void ShowTasksButton_Click(object sender, RoutedEventArgs e)
        {
            ButtonPanel.Visibility = Visibility.Collapsed;
            TaskListContainer.Visibility = Visibility.Visible;
            AddToActivityLog("Tasks viewed", $"Viewed {tasks.Count} tasks");
        }

        private void HideTasksButton_Click(object sender, RoutedEventArgs e)
        {
            TaskListContainer.Visibility = Visibility.Collapsed;
            ButtonPanel.Visibility = Visibility.Visible;
        }

        private void MarkComplete_Click(object sender, RoutedEventArgs e)
        {
            if (TasksListBox.SelectedItem is CyberTask task)
            {
                task.IsCompleted = true;
                AddToActivityLog("Task completed", $"Task: {task.Title}");
                QueueBotMessage($"Marked '{task.Title}' as completed. Great job!");

                // Refresh the list
                TasksListBox.Items.Refresh();
            }
            else
            {
                QueueBotMessage("Please select a task to mark as complete.");
            }
        }

        private void DeleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (TasksListBox.SelectedItem is CyberTask task)
            {
                tasks.Remove(task);
                AddToActivityLog("Task deleted", $"Task: {task.Title}");
                QueueBotMessage($"Removed task: {task.Title}");

                // Hide task list if no tasks left
                if (tasks.Count == 0)
                {
                    HideTasksButton_Click(null, null);
                }
            }
            else
            {
                QueueBotMessage("Please select a task to delete.");
            }
        }

        private void UserInput_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                SendButton_Click(null, null);
            }
        }

        private void ToggleSpeechButton_Click(object sender, RoutedEventArgs e)
        {
            speechEnabled = !speechEnabled;
            ToggleSpeechButton.Content = speechEnabled ? "🔊 Speech On" : "🔇 Speech Off";
            StatusText.Text = speechEnabled ? "Speech synthesis enabled" : "Speech synthesis disabled";
        }

        private void StartQuizButton_Click(object sender, RoutedEventArgs e)
        {
            StartQuiz();
        }

        private void ShowLogButton_Click(object sender, RoutedEventArgs e)
        {
            ShowActivityLog();
        }

        private void SetReminderButton_Click(object sender, RoutedEventArgs e)
        {
            QueueBotMessage("What would you like to be reminded about? Please specify the task and time (e.g., 'Remind me to update passwords tomorrow')");
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            typingTimer.Stop();
            typingTimer.Tick -= TypingTimer_Tick;
            synth?.Dispose();
        }
    }
}